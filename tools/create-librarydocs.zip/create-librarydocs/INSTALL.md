# Install create-librarydocs (global skill)

Source in this repository: `.cursor/skills/create-librarydocs/`

**Do not copy the full skill into every consumer repository.** Install once globally:

```powershell
$SkillRoot = "$env:USERPROFILE\.cursor\skills\create-librarydocs"
New-Item -ItemType Directory -Force "$SkillRoot\reference", "$SkillRoot\scripts" | Out-Null
Copy-Item -Recurse -Force ".cursor\skills\create-librarydocs\*" $SkillRoot
```

Confirm under **Cursor Settings → Rules, Skills, Subagents → Skills**.

## CI / pinned validation

Copy only the validator:

```powershell
Copy-Item .cursor\skills\create-librarydocs\scripts\validate_librarydocs.py tools\
```

Run from repository root:

```powershell
python tools\validate_librarydocs.py --repo-root . --strict
```

## Version

Skill version: **2.1.0** (see `SKILL.md` frontmatter)
